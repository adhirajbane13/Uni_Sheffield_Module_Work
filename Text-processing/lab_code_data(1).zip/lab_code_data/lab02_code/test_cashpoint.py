
from SimpleCashPoint import cashpoint

# Test calls to program:

print('TEST-EXAMPLE 1')
result = cashpoint('1234',3415.55)
print('---------\nRESULT:', result)
print('-' * 50, '\n')

print('TEST-EXAMPLE 2')
result = cashpoint('2345',2200.00)
print('---------\nRESULT:', result)
print('-' * 50, '\n')

print('TEST-EXAMPLE 3')
result = cashpoint('3456',175.55)
print('---------\nRESULT:', result)
print('-' * 50, '\n')



from random import randint

def guess(attempts,numrange):
    number = randint(1,numrange)
    print("Welcome! Can you guess my secret number?")

    # YOUR CODE GOES HERE!

    print("END-OF-GAME: thanks for playing!")


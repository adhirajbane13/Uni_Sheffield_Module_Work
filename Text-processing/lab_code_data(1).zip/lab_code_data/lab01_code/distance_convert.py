# Converts distance in miles to kilometers
miles = 22.7
kilometers = (miles * 8.0) / 5.0
print("Converting distance in miles to kilometers:")
print("Distance in miles:     ", miles)
print("Distance in kilometers:", kilometers)
